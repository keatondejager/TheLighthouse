
=== BRUSH HAND NEW ===

Keith Bates / K-Type © 2013 (version 1.1)
www.k-type.com    -    info@k-type.com

Brush Hand New is a full font based on a copy of Flash Bold called Brush Hand marketed by WSI in the 1990s and more recently distributed through free font sites. Brush Hand was an anonymous redrawing of Flash which simplified, slightly lightened, smoothed out ragged edges, and improved the legibility of the original classic created by Edwin W. Shaar in 1939.

K-Type's New version makes the simplification more refined. Outlines are improved to remove any remaining harshness, resulting in softer, smoother flowing glyphs ideal for titles and display purposes. The letterspacing of the New version is better, the old Brush Hand was spaced erratically and set too loosely. Poorly drafted characters have been redrawn, and a more comprehensive repertoire includes the Latin Extended-A European accented characters.

------------------------------------------------

== Licence Information ==

Brush Hand New is free for personal use only. For information about Commercial and Enterprise Licences please go to:
http://www.k-type.com

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------